/*********************************************************************
*
*   HEADER NAME:
*       CppBot_types.h - Public data types
*
*   Copyright:
*       Software source code by Alex Morozov and Chris D. Locke is
*       licensed under a Creative Commons Attribution-Noncommercial-
*       Share Alike 3.0 United States License
*       (http://creativecommons.org/licenses/by-nc-sa/3.0/us/)
*
*********************************************************************/
#if !defined _CPPBOT_TYPES_H
#define _CPPBOT_TYPES_H

typedef unsigned long long UINT64;
typedef unsigned long long uint64;
typedef unsigned int UINT32;
typedef unsigned int uint32;
typedef unsigned int UINT;
typedef unsigned short int UINT16;
typedef unsigned short int uint16;
typedef unsigned char UINT8;
typedef unsigned char uint8;

typedef signed long long INT64;
typedef signed int INT32;
typedef signed int int32;
typedef signed short int INT16;
typedef signed short int int16;
typedef signed char INT8;
typedef signed char int8;

typedef void ( *FUNCPTR )( void );
typedef UINT32 STATUS;

typedef UINT8 boolean;

#define TRUE    ( 1 )
#define FALSE   ( 0 )

#ifndef _WIN32
    #include <assert.h>
    #define _ASSERT assert
#else
    #include <crtdbg.h>
#endif

#endif /* CPPBOT_TYPES_H */


