/*
 *  SimObject.h
 *  CppBot
 *
 *  Created by Alex on 2/1/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */
 
#pragma once

/**************************************************************************
* SimObject - This is a base class for all simulated objects.
**************************************************************************/
class SimObject
{
public:
    SimObject( );  
    virtual void Update( unsigned int update_rate_ms ) = 0;
    
protected:
    double limit_rate( double x, double prev_x, double max_rate );
};