/*
 *  GLUTDebugWindow.h
 *  CppBot
 *
 *  Created by Alex on 2/2/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#pragma once

#include "GLUTWindow.h"

/**************************************************************************
* A window to display debug information
**************************************************************************/
class GLUTDebugWindow : public GLUTWindow
{
public:
    GLUTDebugWindow( int x, int y ) : GLUTWindow( "Debug", 200, 600, x, y ) { };
    virtual void DisplayCallBack( void );
};