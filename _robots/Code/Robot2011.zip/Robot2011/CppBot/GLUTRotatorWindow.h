/*
 *  GLUTRotator.h
 *  CppBot
 *
 *  Created by Alex on 2/1/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */
#pragma once

#include "GLUTWindow.h"

#include "SimRotator.h"

class GLUTRotatorWindow : public GLUTWindow
{
public:
    GLUTRotatorWindow( const char * name, const SimRotator * p_sim, int x, int y );
    virtual void DisplayCallBack( void );
    
private:
    const SimRotator * m_p_sim;
};