/*
 *  SimObject.cpp
 *  CppBot
 *
 *  Created by Alex on 2/1/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "SimInterface.h"
#include "SimObject.h"

SimObject::SimObject( )
{
SimInterface::Register( this );
}

double SimObject::limit_rate( double x, double prev_x, double max_rate )
{
double rate = x - prev_x;
if( rate > max_rate )
    {
    rate = max_rate;
    }
else if( rate < -max_rate )
    {
    rate = -max_rate;
    }
    
return( prev_x + rate );
}
