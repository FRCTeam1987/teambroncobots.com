/*********************************************************************
*
*   CppBot.h - C++ Robot simulator header
*
*   Copyright:
*       Software source code by Alex Morozov and Chris D. Locke is
*       licensed under a Creative Commons Attribution-Noncommercial-
*       Share Alike 3.0 United States License
*       (http://creativecommons.org/licenses/by-nc-sa/3.0/us/)
*
*********************************************************************/
#pragma once

void get_joy
    (
    int                 idx,
    int *               x,
    int *               y
    );
    
void set_dio
    (
    int                 slot,
    int                 chan,
    bool                val
    );
        
