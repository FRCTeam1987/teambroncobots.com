/*----------------------------------------------------------------------------*/
/* Copyright (c) FIRST 2008. All Rights Reserved.							  */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in $(WIND_BASE)/WPILib.  */
/*----------------------------------------------------------------------------*/

#ifndef JAGUAR_H
#define JAGUAR_H

#include "SpeedController.h"

/**
 * Luminary Micro Jaguar Speed Control
 */
class Jaguar : public SpeedController
{
public:
    Jaguar(UINT32 channel) : SpeedController( channel ) { }
	//TODO: Jaguar(UINT32 slot, UINT32 channel);
	//TODO: float Get();

private:
	//TODO: void InitJaguar();
};
#endif

