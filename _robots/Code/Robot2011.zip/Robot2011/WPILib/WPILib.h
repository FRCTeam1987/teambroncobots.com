/*
 *  WPILib.h
 *  CppBot
 *
 *  Created by Alex on 1/30/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef WPILIB_H
#define WPILIB_H

#include <time.h>

#include "DigitalInput.h"
#include "DriverStation.h"
#include "Encoder.h"
#include "Gyro.h"
#include "IterativeRobot.h"
#include "Jaguar.h"
#include "Joystick.h"
#include "Solenoid.h"
#include "RobotDrive.h"

static inline double GetClock() 
{ 
    return( ( double )time( NULL ) );
}


#endif