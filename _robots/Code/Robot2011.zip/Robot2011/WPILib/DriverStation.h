/*----------------------------------------------------------------------------*/
/* Copyright (c) FIRST 2008. All Rights Reserved.							  */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in $(WIND_BASE)/WPILib.  */
/*----------------------------------------------------------------------------*/

#ifndef __DRIVER_STATION_H__
#define __DRIVER_STATION_H__

//TODO: #include "Dashboard.h"
//TODO: #include "SensorBase.h"
//TODO: #include "Task.h"

struct FRCControlData;
class AnalogChannel;

/**
 * Provide access to the network communication data to / from the Driver Station.
 */
class DriverStation //TODO: : public SensorBase
{
public:
	//TODO: enum Alliance {kRed, kBlue, kInvalid};

	//TODO: virtual ~DriverStation();
	static DriverStation *GetInstance() { return( NULL ); };

	//TODO: static const UINT32 kBatterySlot = 1;
	//TODO: static const UINT32 kBatteryChannel = 8;
	//TODO: static const UINT32 kJoystickPorts = 4;
	//TODO: static const UINT32 kJoystickAxes = 6;

	//TODO: float GetStickAxis(UINT32 stick, UINT32 axis);
	//TODO: short GetStickButtons(UINT32 stick);

	//TODO: float GetAnalogIn(UINT32 channel);
	//TODO: bool GetDigitalIn(UINT32 channel);
	//TODO: void SetDigitalOut(UINT32 channel, bool value);
	//TODO: bool GetDigitalOut(UINT32 channel);

	//TODO: bool IsDisabled();
	//TODO: bool IsAutonomous();
	//TODO: bool IsOperatorControl();

	//TODO: UINT32 GetPacketNumber();
	//TODO: Alliance GetAlliance();
	//TODO: UINT32 GetLocation();

	//TODO: float GetBatteryVoltage();

	//TODO: Dashboard& GetDashboardPacker(void) {return m_dashboard;}

protected:
	//TODO: DriverStation();

	//TODO: void GetData();
	//TODO: void SetData();

private:
	//TODO: static void InitTask(DriverStation *ds);
	//TODO: static DriverStation *m_instance;
	///< TODO: Get rid of this and use the semaphore signaling
	//TODO: static const float kUpdatePeriod = 0.02;

	//TODO: void Run();

	//TODO: struct FRCControlData *m_controlData;
	//TODO: char *m_userControl;
	//TODO: char *m_userStatus;
	//TODO: UINT8 m_digitalOut;
	//TODO: AnalogChannel *m_batteryChannel;
	//TODO: Task m_task;
	//TODO: Dashboard m_dashboard;
};

#endif

