/*
 *  SpeedController.cpp
 *  CppBot
 *
 *  Created by Alex on 1/30/10.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

#include "SimInterface.h"

#include "SpeedController.h"

SpeedController::SpeedController( UINT32 channel )
    : m_channel( channel )
{
}


void SpeedController::Set(float value)
{
SimInterface::SetPWM( m_channel, value );
}