#ifndef ROBOTPARAMETER_H
#define ROBOTPARAMETER_H
#include "WPILib.h"
#define LIFT_MOTOR_CHANNEL  5
#define LIFT_ENCODER_A_CHNL 5       // HACK: this must be same as the motor channel for the simulator to work correctly
#define LIFT_ENCODER_B_CHNL 0       // HACK: simulator does not care about this
#define ARM_1_MOTOR_CHANNEL 6
#define LIFT_LO_SWITCH      1
#define LIFT_HI_SWITCH      2
#define ARM_1_LO_SWITCH     3
#define ARM_1_HI_SWITCH     4
#define LEFT_LF_CHANNEL     5
#define CENTER_LF_CHANNEL   LEFT_LF_CHANNEL + 1     // HACK: must be this for simulator to work correctly
#define RIGHT_LF_CHANNEL    CENTER_LF_CHANNEL + 1   // HACK: must be this for simulator to work correctly

// Analog channels
#define YAW_GYRO_CHANNEL    1
#define LIFT_GYRO_CHANNEL   2
#define ARM_GYRO_CHANNEL    3
#define GYRO_CHANNEL		YAW_GYRO_CHANNEL

#endif
