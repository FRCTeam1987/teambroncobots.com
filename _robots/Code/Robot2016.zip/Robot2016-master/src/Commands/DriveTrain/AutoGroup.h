#ifndef AutoGroup_H
#define AutoGroup_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class AutoGroup: public CommandGroup
{
public:
	AutoGroup();
};

#endif
