#ifndef AutoLowBar_H
#define AutoLowBar_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class AutoLowBar: public CommandGroup
{
public:
	AutoLowBar();
	void End();
	void Interrupted();
};

#endif
