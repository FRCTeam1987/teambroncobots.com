#ifndef AutoChevalDeFrise_H
#define AutoChevalDeFrise_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class AutoChevalDeFrise: public CommandGroup
{
public:
	AutoChevalDeFrise();
	void End();
	void Interrupted();
};

#endif
