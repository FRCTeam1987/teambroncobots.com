#ifndef CollectBall_H
#define CollectBall_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class CollectBall: public CommandGroup
{
public:
	CollectBall();
};

#endif
