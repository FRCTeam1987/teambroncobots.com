#ifndef StopIntakeAndCollector_H
#define StopIntakeAndCollector_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class StopIntakeAndCollector: public CommandGroup
{
public:
	StopIntakeAndCollector();
};

#endif
