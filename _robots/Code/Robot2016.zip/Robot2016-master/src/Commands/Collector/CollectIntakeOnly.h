#ifndef CollectIntakeOnly_H
#define CollectIntakeOnly_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class CollectIntakeOnly: public CommandGroup
{
public:
	CollectIntakeOnly();
};

#endif
