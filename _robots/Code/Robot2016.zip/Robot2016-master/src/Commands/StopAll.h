#ifndef StopAll_H
#define StopAll_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class StopAll: public CommandGroup
{
public:
	StopAll();
};

#endif
