#ifndef RunShooterAndIntake_H
#define RunShooterAndIntake_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class RunShooterAndIntake: public CommandGroup
{
public:
	RunShooterAndIntake();
};

#endif
