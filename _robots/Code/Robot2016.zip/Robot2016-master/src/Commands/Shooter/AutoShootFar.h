#ifndef AutoShootFar_H
#define AutoShootFar_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class AutoShootFar: public CommandGroup
{
public:
	AutoShootFar();
};

#endif
