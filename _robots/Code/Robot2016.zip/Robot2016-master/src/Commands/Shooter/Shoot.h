#ifndef Shoot_H
#define Shoot_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class Shoot: public CommandGroup
{
public:
	Shoot();
};

#endif
