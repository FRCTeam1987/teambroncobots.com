#ifndef ReverseShooterAndIntake_H
#define ReverseShooterAndIntake_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class ReverseShooterAndIntake: public CommandGroup
{
public:
	ReverseShooterAndIntake();
};

#endif
