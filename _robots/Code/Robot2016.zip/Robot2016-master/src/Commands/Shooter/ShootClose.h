#ifndef ShootClose_H
#define ShootClose_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class ShootClose: public CommandGroup
{
public:
	ShootClose();
};

#endif
