#ifndef LoadBall_H
#define LoadBall_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class LoadBall: public CommandGroup
{
public:
	LoadBall();
};

#endif
