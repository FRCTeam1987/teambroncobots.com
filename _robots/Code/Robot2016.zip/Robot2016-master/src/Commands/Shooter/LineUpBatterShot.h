#ifndef LineUpBatterShot_H
#define LineUpBatterShot_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class LineUpBatterShot: public CommandGroup
{
public:
	LineUpBatterShot();
};

#endif
