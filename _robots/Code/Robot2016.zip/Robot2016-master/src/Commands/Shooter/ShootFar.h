#ifndef ShootFar_H
#define ShootFar_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class ShootFar: public CommandGroup
{
public:
	ShootFar();
};

#endif
