#ifndef BottomStack_H
#define BottomStack_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"


class BottomStack: public CommandGroup
{
public:
	BottomStack(bool isPracticeBot);
};

#endif
