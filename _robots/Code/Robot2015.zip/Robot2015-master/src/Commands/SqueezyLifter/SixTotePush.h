#ifndef SixTotePush_H
#define SixTotePush_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class SixTotePush: public CommandGroup
{
public:
	SixTotePush(bool isPracticeBot);
};

#endif
