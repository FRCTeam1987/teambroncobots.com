#include "SixToteStackAuto.h"

/**
 * Stack six totes then push stack
 */
SixToteStackAuto::SixToteStackAuto()
{
//		AddSequential(new PushInOut(PushInOut::kIn));
//		AddSequential(new WaitCommand(.25));
		AddSequential(new PlatformInOut(PlatformInOut::kOut));
//		AddParallel(new SqueezyUpDown(CommandBase::squeezyLifter->isPracticeBot() ? HOLDHEIGHT_PRACTICE : HOLDHEIGHT_COMPETITION, CommandBase::squeezyLifter->kFirstTote));


		AddSequential(new LiftTote(CommandBase::squeezyLifter->isPracticeBot(), CommandBase::squeezyLifter->kFirstTote));
		AddSequential(new LiftTote(CommandBase::squeezyLifter->isPracticeBot(), CommandBase::squeezyLifter->kMiddleTote));
		AddSequential(new LiftTote(CommandBase::squeezyLifter->isPracticeBot(), CommandBase::squeezyLifter->kMiddleTote));
		AddSequential(new LiftTote(CommandBase::squeezyLifter->isPracticeBot(), CommandBase::squeezyLifter->kMiddleTote));
		AddSequential(new LiftTote(CommandBase::squeezyLifter->isPracticeBot(), CommandBase::squeezyLifter->kMiddleTote));
		AddSequential(new LiftTote(CommandBase::squeezyLifter->isPracticeBot(), CommandBase::squeezyLifter->kLastTote));

		AddSequential(new PlatformInOut(PlatformInOut::kIn));
		AddSequential(new SqueezyUpDown(CommandBase::squeezyLifter->isPracticeBot() ? GRABHEIGHTSCORINGPLATFORM_PRACTICE : GRABHEIGHTPLATFORM_COMPETITION, 6));
		AddSequential(new PushInOut(PushInOut::kOut));
		AddSequential(new WaitCommand(.2));//Lets pushers fully push
		AddSequential(new PushInOut(PushInOut::kIn));
		AddParallel(new SqueezyUpDown(CommandBase::squeezyLifter->isPracticeBot() ? HOLDHEIGHT_PRACTICE : HOLDHEIGHT_COMPETITION, CommandBase::squeezyLifter->kFirstTote));
//		AddParallel(new PlatformInOut(PlatformInOut::kOut));
}
