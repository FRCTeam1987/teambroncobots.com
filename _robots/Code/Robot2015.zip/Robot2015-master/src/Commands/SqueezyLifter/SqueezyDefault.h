#ifndef SqueezyDefault_H
#define SqueezyDefault_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"
#include "SixToteStackAuto.h"
#include "FiveStackAuto.h"
#include "FourStackAuto.h"
#include "ThreeToteStackAuto.h"
#include "TwoToteStackAuto.h"
#include "OneToteStackAuto.h"

class SqueezyDefault: public CommandGroup
{
public:
	SqueezyDefault();
};

#endif
