#ifndef EndStack_H
#define EndStack_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class EndStack: public CommandGroup
{
public:
	EndStack(bool isPracticeBot);
};

#endif
