#ifndef StartFullyAuto_H
#define StartFullyAuto_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class StartFullyAuto: public CommandGroup
{
public:
	StartFullyAuto();
};

#endif
