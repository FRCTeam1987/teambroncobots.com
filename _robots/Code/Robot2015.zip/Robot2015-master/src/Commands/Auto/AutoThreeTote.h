#ifndef AutoThreeTote_H
#define AutoThreeTote_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class AutoThreeTote: public CommandGroup
{
public:
	AutoThreeTote(bool isPracticeBot);
};

#endif
