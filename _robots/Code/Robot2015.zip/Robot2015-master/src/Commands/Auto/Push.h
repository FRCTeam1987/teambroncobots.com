#ifndef Push_H
#define Push_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class Push: public CommandGroup
{
public:
	Push();
};

#endif
