#ifndef LowerConveyorWait_H
#define LowerConveyorWait_H

#include "Commands/CommandGroup.h"
#include "WPILib.h"

class LowerConveyorWait: public CommandGroup
{
public:
	LowerConveyorWait();
};

#endif
