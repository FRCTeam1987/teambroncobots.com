/*
 * library.cpp
 *
 *  Created on: Jan 30, 2015
 *      Author: LAPSTATION0
 */

#include "library.h"

float abs(float num)

{
	if (num < 0) {
		num*=-1;
	}
	return num;
}
