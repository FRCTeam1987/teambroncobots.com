#ifndef LIBRARY_H
#define LIBRARY_H

float abs(float num);

#endif // LIBRARY_H
