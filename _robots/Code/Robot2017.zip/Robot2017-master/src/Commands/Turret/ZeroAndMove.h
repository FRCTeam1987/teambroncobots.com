#ifndef ZeroAndMove_H
#define ZeroAndMove_H

#include <Commands/CommandGroup.h>

class ZeroAndMove : public frc::CommandGroup {
public:
	ZeroAndMove();
};

#endif  // ZeroAndMove_H
