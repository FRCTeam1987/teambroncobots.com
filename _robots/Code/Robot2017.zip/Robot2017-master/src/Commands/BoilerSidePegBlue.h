#ifndef BoilerSidePegBlue_H
#define BoilerSidePegBlue_H

#include <Commands/CommandGroup.h>

class BoilerSidePegBlue : public frc::CommandGroup {
public:
	BoilerSidePegBlue();
};

#endif  // BoilerSidePegBlue_H
