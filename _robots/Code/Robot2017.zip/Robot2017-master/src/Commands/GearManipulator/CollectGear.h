#ifndef CollectGear_H
#define CollectGear_H

#include <Commands/CommandGroup.h>

class CollectGear : public CommandGroup {
public:
	CollectGear();
};

#endif  // CollectGear_H
