#ifndef PlaceGear_H
#define PlaceGear_H

#include <Commands/CommandGroup.h>

class PlaceGear : public frc::CommandGroup {
public:
	PlaceGear();
};

#endif  // PlaceGear_H
