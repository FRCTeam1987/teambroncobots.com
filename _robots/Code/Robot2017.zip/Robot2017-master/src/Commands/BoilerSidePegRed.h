#ifndef BoilerSidePegRed_H
#define BoilerSidePegRed_H

#include <Commands/CommandGroup.h>

class BoilerSidePegRed : public CommandGroup {
public:
	BoilerSidePegRed();
};

#endif  // BoilerSidePegRed_H
