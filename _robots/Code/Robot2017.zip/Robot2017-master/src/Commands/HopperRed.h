#ifndef HopperRed_H
#define HopperRed_H

#include <Commands/CommandGroup.h>

class HopperRed : public frc::CommandGroup {
public:
	HopperRed();
};

#endif  // HopperRed_H
