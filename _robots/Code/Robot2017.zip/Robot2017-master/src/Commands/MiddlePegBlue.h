#ifndef MiddlePegBlue_H
#define MiddlePegBlue_H

#include <Commands/CommandGroup.h>

class MiddlePegBlue : public CommandGroup {
public:
	MiddlePegBlue();
};

#endif  // MiddlePegBlue_H
