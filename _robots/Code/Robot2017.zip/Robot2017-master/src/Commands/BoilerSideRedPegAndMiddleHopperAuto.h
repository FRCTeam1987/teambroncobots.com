#ifndef BoilerSideRedPegAndMiddleHopperAuto_H
#define BoilerSideRedPegAndMiddleHopperAuto_H

#include <Commands/CommandGroup.h>

class BoilerSideRedPegAndMiddleHopperAuto : public frc::CommandGroup {
public:
	BoilerSideRedPegAndMiddleHopperAuto();
};

#endif  // BoilerSideRedPegAndMiddleHopperAuto_H
