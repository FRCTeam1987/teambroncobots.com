#ifndef Climb_H
#define Climb_H

#include <Commands/CommandGroup.h>

class Climb : public frc::CommandGroup {
public:
	Climb();
};

#endif  // Climb_H
