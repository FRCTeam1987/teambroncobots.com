#ifndef PlaceGearFromDriveStation_H
#define PlaceGearFromDriveStation_H

#include <Commands/CommandGroup.h>

class PlaceGearFromDriveStation : public CommandGroup {
public:
	PlaceGearFromDriveStation();
};

#endif  // PlaceGearFromDriveStation_H
