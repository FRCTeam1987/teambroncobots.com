#ifndef BlueEdgeDriveStationToHopper_H
#define BlueEdgeDriveStationToHopper_H

#include <Commands/CommandGroup.h>

class BlueEdgeDriveStationToHopper : public CommandGroup {
public:
	BlueEdgeDriveStationToHopper();
};

#endif  // BlueEdgeDriveStationToHopper_H
