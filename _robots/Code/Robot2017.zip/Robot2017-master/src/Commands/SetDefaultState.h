#ifndef SetDefaultState_H
#define SetDefaultState_H

#include <Commands/CommandGroup.h>

class SetDefaultState : public frc::CommandGroup {
public:
	SetDefaultState();

};

#endif  // SetDefaultState_H
