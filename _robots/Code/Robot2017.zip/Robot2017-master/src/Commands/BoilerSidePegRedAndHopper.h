#ifndef BoilerSidePegRedAndHopper_H
#define BoilerSidePegRedAndHopper_H

#include <Commands/CommandGroup.h>

class BoilerSidePegRedAndHopper : public frc::CommandGroup {
public:
	BoilerSidePegRedAndHopper();
};

#endif  // BoilerSidePegRedAndHopper_H
