#ifndef PlaceGearAndHopperAuto_H
#define PlaceGearAndHopperAuto_H

#include <Commands/CommandGroup.h>

class PlaceGearAndHopperAuto : public CommandGroup {
public:
	PlaceGearAndHopperAuto();
};

#endif  // PlaceGearAndHopperAuto_H
