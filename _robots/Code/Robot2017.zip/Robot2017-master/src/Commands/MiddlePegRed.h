#ifndef MiddlePegRed_H
#define MiddlePegRed_H

#include <Commands/CommandGroup.h>

class MiddlePegRed : public CommandGroup {
public:

	MiddlePegRed();
	void Initialize();
	void End();
};

#endif  // MiddlePegRed_H
