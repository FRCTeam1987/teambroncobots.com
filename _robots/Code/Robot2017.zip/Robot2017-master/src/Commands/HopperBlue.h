#ifndef HopperBlue_H
#define HopperBlue_H

#include <Commands/CommandGroup.h>

class HopperBlue : public CommandGroup {
public:
	HopperBlue();
};

#endif  // HopperBlue_H
