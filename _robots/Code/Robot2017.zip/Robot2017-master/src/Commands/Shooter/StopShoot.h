#ifndef StopShoot_H
#define StopShoot_H

#include <Commands/CommandGroup.h>

class StopShoot : public frc::CommandGroup {
public:
	StopShoot();
};

#endif  // StopShoot_H
