#ifndef CollectFuel_H
#define CollectFuel_H

#include <Commands/CommandGroup.h>

class CollectFuel : public frc::CommandGroup {
public:
	CollectFuel();
};

#endif  // CollectFuel_H
