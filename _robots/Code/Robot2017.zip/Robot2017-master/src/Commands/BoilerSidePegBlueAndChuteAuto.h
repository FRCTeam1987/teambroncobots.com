#ifndef BoilerSidePegBlueAndChuteAuto_H
#define BoilerSidePegBlueAndChuteAuto_H

#include <Commands/CommandGroup.h>

class BoilerSidePegBlueAndChuteAuto : public frc::CommandGroup {
public:
	BoilerSidePegBlueAndChuteAuto();
};

#endif  // BoilerSidePegBlueAndChuteAuto_H
