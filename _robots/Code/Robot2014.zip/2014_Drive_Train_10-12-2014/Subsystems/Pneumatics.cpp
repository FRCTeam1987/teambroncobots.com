#include "Pneumatics.h"
#include "../Robotmap.h"

Pneumatics::Pneumatics() : Subsystem("Pneumatics")
{
	compressor = new Compressor(COMPRESSOR_PRESSURE_SWITCH, COMPRESSOR_RELAY);
}
    
void Pneumatics::InitDefaultCommand() 
{
	
}

UINT32 Pneumatics::GetPressureSwitchValue() 
{
	return compressor->GetPressureSwitchValue();
}

void Pneumatics::Start()
{
	compressor->Start();
}

void Pneumatics::Stop()
{
	compressor->Stop();
}
