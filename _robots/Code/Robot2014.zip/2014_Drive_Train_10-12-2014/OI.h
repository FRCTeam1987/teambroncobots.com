#ifndef OI_H
#define OI_H

#include "WPILib.h"

class BroncoJoy;
class XboxController;

class OI {
private:
	BroncoJoy * stick1;
	JoystickButton * shift;
	XboxController * xbox;
	JoystickButton * shiftXbox;
public:
	OI();
	
	Joystick *getStick();
	XboxController *getXbox();
};

#endif
