#ifndef SHIFTLO_H
#define SHIFTLO_H

#include "../../CommandBase.h"

/**
 *
 *
 * @author LAPSTATION0
 */
class ShiftLo: public CommandBase 
{
public:
	ShiftLo();
	virtual void Initialize();
	virtual void Execute();
	virtual bool IsFinished();
	virtual void End();
	virtual void Interrupted();
};

#endif
