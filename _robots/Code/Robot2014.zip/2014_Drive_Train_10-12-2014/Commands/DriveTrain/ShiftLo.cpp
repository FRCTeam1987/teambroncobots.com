#include "ShiftLo.h"

ShiftLo::ShiftLo() 
{
	// Use requires() here to declare subsystem dependencies
	Requires(driveTrain);
}

// Called just before this Command runs the first time
void ShiftLo::Initialize() 
{
	driveTrain->ShiftLo();
}

// Called repeatedly when this Command is scheduled to run
void ShiftLo::Execute() {
	
}

// Make this return true when this Command no longer needs to run execute()
bool ShiftLo::IsFinished() 
{
	//Ends after the shift.
	return true;
}

// Called once after isFinished returns true
void ShiftLo::End() 
{
	
}

// Called when another command which requires one or more of the same
// subsystems is scheduled to run
void ShiftLo::Interrupted() 
{
	
}
