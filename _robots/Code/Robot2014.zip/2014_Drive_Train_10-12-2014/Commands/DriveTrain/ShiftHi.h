#ifndef SHIFTHI_H
#define SHIFTHI_H

#include "../../CommandBase.h"

/**
 *
 *
 * @author LAPSTATION0
 */
class ShiftHi: public CommandBase
{
public:
	ShiftHi();
	virtual void Initialize();
	virtual void Execute();
	virtual bool IsFinished();
	virtual void End();
	virtual void Interrupted();
};

#endif
