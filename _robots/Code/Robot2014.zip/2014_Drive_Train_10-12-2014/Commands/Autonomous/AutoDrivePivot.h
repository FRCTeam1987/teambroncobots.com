#ifndef AUTODRIVEPIVOT_H
#define AUTODRIVEPIVOT_H

#include "Commands/CommandGroup.h"

/**
 *
 *
 * @author LAPSTATION0
 */
class AutoDrivePivot: public CommandGroup 
{
public:	
	AutoDrivePivot();
};

#endif
