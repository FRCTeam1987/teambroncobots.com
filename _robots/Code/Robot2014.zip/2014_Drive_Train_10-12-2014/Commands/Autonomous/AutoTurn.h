#ifndef AUTOTURN_H
#define AUTOTURN_H

#include "../../CommandBase.h"

/**
 *
 *
 * @author LAPSTATION0
 */
class AutoTurn: public CommandBase 
{
private:
	int desiredAngle;
	float turnSpeed;
public:
	AutoTurn(int inDesiredAngle, float inTurnSpeed);
	virtual void Initialize();
	virtual void Execute();
	virtual bool IsFinished();
	virtual void End();
	virtual void Interrupted();
};

#endif
