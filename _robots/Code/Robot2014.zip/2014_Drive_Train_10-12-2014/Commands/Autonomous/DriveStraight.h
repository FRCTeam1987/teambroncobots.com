#ifndef DRIVESTRAIGHT_H
#define DRIVESTRAIGHT_H

#include "../../CommandBase.h"

/**
 *
 *
 * @author LAPSTATION0
 */
class DriveStraight: public CommandBase
{
private:
	static const float kP = 0.03;
	double m_driveDistance;
	float m_driveSpeed;
public:
	DriveStraight(double driveDistance, float driveSpeed);
	virtual void Initialize();
	virtual void Execute();
	virtual bool IsFinished();
	virtual void End();
	virtual void Interrupted();
};

#endif
