# Robot 2023 ![Build Status](https://github.com/FRCTeam1987/Robot2023/actions/workflows/main.yml/badge.svg)

Uses [3061-lib (448c250)](https://github.com/HuskieRobotics/3061-lib/tree/448c250)

**Note for programmers:** Check for updates in 3061-lib [here](https://github.com/HuskieRobotics/3061-lib/compare/448c250...main)
