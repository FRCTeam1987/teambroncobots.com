package org.usfirst.frc.team1987.robot;

public enum DriveMode {
	PIVOT,
	STRAIGHT,
	TRAJECTORY,
	DRIVEPATHLOW,
	DRIVEPATHSTRAIGHT,
	DRIVEPATHTURNS
}
