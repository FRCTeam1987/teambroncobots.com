package org.usfirst.frc.team1987.robot;

public enum CollectorHeight {
	FLOOR,
	HOLD,
	MIDDLE,
	TOP
}
