package org.usfirst.frc.team1987.robot;

public enum AutonomousMode {
	Both,
	Near,
	Scale,
	Switch
}
