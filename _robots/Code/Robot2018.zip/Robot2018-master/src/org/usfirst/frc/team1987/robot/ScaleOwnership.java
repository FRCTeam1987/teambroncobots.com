package org.usfirst.frc.team1987.robot;

public enum ScaleOwnership {
	OWNED,
	NEUTRAL,
	DISOWNED,
	DISOWNED_WORST
}
