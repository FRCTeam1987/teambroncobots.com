package org.usfirst.frc.team1987.robot;

public enum StartingPosition {
	Left,
	Middle,
	Right
}
