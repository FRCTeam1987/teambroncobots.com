package org.usfirst.frc.team1987.robot.commands.elevator;

import org.usfirst.frc.team1987.robot.Robot;

import edu.wpi.first.wpilibj.command.InstantCommand;

/**
 *
 */
public class ToggleRatchet extends InstantCommand {

//    public ToggleRatchet() {
//        super();
//        requires(Robot.elevator);
//    }
//
//    // Called once when the command executes
//    protected void initialize() {
//        Robot.elevator.toggleRatchet();
//    }

}
