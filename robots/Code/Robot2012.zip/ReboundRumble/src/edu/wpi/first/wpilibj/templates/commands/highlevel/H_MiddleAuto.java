/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.wpi.first.wpilibj.templates.commands.highlevel;

import edu.wpi.first.wpilibj.command.CommandGroup;
import edu.wpi.first.wpilibj.templates.RobotMap;
import edu.wpi.first.wpilibj.templates.commands.lowlevel.L_Chassis_DriveStraight;
import edu.wpi.first.wpilibj.templates.commands.lowlevel.L_Elevator_TimedUp;

/**
 *
 * @author team1987
 */
public class H_MiddleAuto extends CommandGroup {
    
    public H_MiddleAuto() {
        
        // Add Commands here:
        // e.g. addSequential(new Command1());
        //      addSequential(new Command2());
        // these will run in order.

        // To run multiple commands at the same time,
        // use addParallel()
        // e.g. addParallel(new Command1());
        //      addSequential(new Command2());
        // Command1 and Command2 will run in parallel.

        // A command group will require all of the subsystems that each member
        // would require.
        // e.g. if Command1 requires chassis, and Command2 requires arm,
        // a CommandGroup containing them would require both the chassis and the
        // arm.
      
        addParallel(new H_ShooterPreset(-0.66/*-0.625*/, RobotMap.KEY_MOTOR_ANGLE, RobotMap.KEY_MOTOR_RATIO, 1));
        addSequential(new L_Elevator_TimedUp(4000));
        //addSequential(new H_elevatorShooterFeed());
        //addSequential(new H_elevatorShooterFeed());
        addSequential(new L_Chassis_DriveStraight(1.6, -1));
        addSequential(new L_Chassis_DriveStraight(.2, 1));
        addSequential(new H_BridgeArm_ChangePosition(2));
    }
}
