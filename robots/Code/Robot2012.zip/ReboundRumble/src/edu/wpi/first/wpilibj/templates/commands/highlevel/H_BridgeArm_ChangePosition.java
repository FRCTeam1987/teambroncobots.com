/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.wpi.first.wpilibj.templates.commands.highlevel;

import edu.wpi.first.wpilibj.templates.commands.CommandBase;

/**
 *
 * @author team1987
 */
public class H_BridgeArm_ChangePosition extends CommandBase {

    private int pos;
    
    public H_BridgeArm_ChangePosition(int desiredPosition) {
        
        // Use requires() here to declare subsystem dependencies
        // eg. requires(chassis);
        this.pos = desiredPosition;
        requires(bridgeArm);
    }

    // Called just before this Command runs the first time
    protected void initialize() {
        System.out.println("BRIDGEARM INIT");
    }

    // Called repeatedly when this Command is scheduled to run
    protected void execute() {
        System.out.println("BRIDGEARM EXE");
        if (pos == 1)
            bridgeArm.armUp();
        if (pos == 2){
            System.out.println("BRIDGEARM 2");
            bridgeArm.armDown();
        }
        else if (pos == 3){
            System.out.println("BRIDGEARM 3");
            bridgeArm.armToggle();
        }
    }

    // Make this return true when this Command no longer needs to run execute()
    protected boolean isFinished() {
        System.out.println("BRIDGEARM FIN");
        return bridgeArm.positionChanged();
    }

    // Called once after isFinished returns true
    protected void end() {
    }

    // Called when another command which requires one or more of the same
    // subsystems is scheduled to run
    protected void interrupted() {
    }
}
