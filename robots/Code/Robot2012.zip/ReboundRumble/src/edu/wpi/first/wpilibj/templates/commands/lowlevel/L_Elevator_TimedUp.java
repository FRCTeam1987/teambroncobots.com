/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.wpi.first.wpilibj.templates.commands.lowlevel;

import edu.wpi.first.wpilibj.templates.commands.CommandBase;

/**
 *
 * @author team1987
 */
public class L_Elevator_TimedUp extends CommandBase {
    private float duration;
    private long startUpTime;
    private long currentUpTime;
    
    public L_Elevator_TimedUp(float time) {
        // Use requires() here to declare subsystem dependencies
        // eg. requires(chassis);
        requires(elevator);
        duration = time;
    }

    // Called just before this Command runs the first time
    protected void initialize() {
        startUpTime = System.currentTimeMillis();
        elevator.up();
    }

    // Called repeatedly when this Command is scheduled to run
    protected void execute() {
        currentUpTime = System.currentTimeMillis();
    }

    // Make this return true when this Command no longer needs to run execute()
    protected boolean isFinished() {
        return (currentUpTime - startUpTime >= duration);
    }

    // Called once after isFinished returns true
    protected void end() {
    }

    // Called when another command which requires one or more of the same
    // subsystems is scheduled to run
    protected void interrupted() {
    }
}
