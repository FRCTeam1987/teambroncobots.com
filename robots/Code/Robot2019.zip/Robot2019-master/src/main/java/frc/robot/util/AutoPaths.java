package frc.robot.util;

import jaci.pathfinder.Pathfinder;
import jaci.pathfinder.Waypoint;

public class AutoPaths {

    public static Waypoint[] test = new Waypoint[] {
        new Waypoint(0.0, 0.0, Pathfinder.d2r(0)),
        new Waypoint(6.0, 2.0, Pathfinder.d2r(0))
    };
        
    
}
